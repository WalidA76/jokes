import sys, os, json, glob, asyncio
from playwright.async_api import async_playwright
BASE=os.path.dirname(os.path.abspath(__file__)); os.chdir(BASE); os.makedirs('frames',exist_ok=True)
def chrome():
    c=glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome')+glob.glob(os.path.expanduser('~/.cache/ms-playwright/chromium-*/chrome-linux/chrome'))
    return c[0] if c else None
# usage: python3 cap.py K N [START] [MAXFRAMES]   (run K=0..N-1 in parallel, N=4 is a good default)
k,n=int(sys.argv[1]),int(sys.argv[2]); start=int(sys.argv[3]) if len(sys.argv)>3 else 0
FPS=30; T=json.load(open('timing.json')); total=int(round(T['total']*FPS))
if len(sys.argv)>4: total=min(total,int(sys.argv[4]))
W,H=T.get('size',[1080,1920])
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=chrome(),args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':W,'height':H})
        await pg.goto('file://'+BASE+'/index.html'); await pg.evaluate('document.fonts.ready')
        for f in range(k+start,total,n):
            await pg.evaluate(f'render({f/FPS})'); await pg.screenshot(path=f'frames/f{f:05d}.jpg',type='jpeg',quality=94)
        await b.close()
asyncio.run(main())
