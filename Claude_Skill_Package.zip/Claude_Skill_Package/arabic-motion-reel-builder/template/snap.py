import sys, os, json, glob, asyncio
from playwright.async_api import async_playwright
BASE=os.path.dirname(os.path.abspath(__file__)); os.chdir(BASE); os.makedirs('frames',exist_ok=True)
def chrome():
    c=glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome')+glob.glob(os.path.expanduser('~/.cache/ms-playwright/chromium-*/chrome-linux/chrome'))
    return c[0] if c else None
# usage: python3 snap.py out_prefix t1 t2 ...   (preview single frames, seconds)
ts=[float(x) for x in sys.argv[2:]]
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=chrome(),args=['--no-sandbox'])
        pg=await b.new_page(viewport={'width':1080,'height':1920})
        pg.on('pageerror',lambda e:print('ERR',e))
        await pg.goto('file://'+BASE+'/index.html'); await pg.evaluate('document.fonts.ready')
        for t in ts:
            await pg.evaluate(f'render({t})'); await pg.screenshot(path=f'{sys.argv[1]}_{t:05.2f}.png')
        await b.close()
asyncio.run(main())
