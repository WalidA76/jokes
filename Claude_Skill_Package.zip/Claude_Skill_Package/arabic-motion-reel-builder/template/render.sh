#!/bin/bash
# usage: bash render.sh voice.wav output.mp4      (run inside the working copy of template/, after cap.py finished)
set -e; cd "$(dirname "$0")"
VOICE=$1; OUT=$2; DUR=$(python3 -c "import json;print(json.load(open('timing.json'))['total'])")
python3 audio.py
ffmpeg -y -loglevel error -i "$VOICE" -i sfx.wav -i pad.wav -filter_complex "
[0:a]highpass=f=80,afftdn=nr=8:nf=-45,equalizer=f=3000:t=q:w=1:g=2,acompressor=threshold=-20dB:ratio=3:attack=10:release=150:makeup=3,loudnorm=I=-14:TP=-1.5,apad=whole_dur=$DUR,asplit=3[v][s1][s2];
[1:a]lowpass=f=9000,volume=0.5[fx];[2:a]lowpass=f=1200,volume=0.2[pd];
[pd][s1]sidechaincompress=threshold=0.01:ratio=12:attack=15:release=500[pdd];
[fx][s2]sidechaincompress=threshold=0.02:ratio=2.5:attack=10:release=250[fxd];
[v][pdd][fxd]amix=inputs=3:normalize=0:duration=first,alimiter=limit=0.95,atrim=0:$DUR[o]" -map "[o]" -ar 44100 mix.wav
ffmpeg -y -loglevel error -framerate 30 -i frames/f%05d.jpg -i mix.wav -c:v libx264 -preset slow -crf 17 -pix_fmt yuv420p -r 30 -c:a aac -b:a 192k -movflags +faststart -t $DUR "$OUT"
echo "done: $OUT"
