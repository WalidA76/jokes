---
name: arabic-motion-reel-builder
description: Build a short Arabic motion-graphics video (Reels/TikTok/Shorts, ~30-60s) from a creative brief plus a voice-over file - kinetic Arabic typography, aperture/lens motifs, AI-workflow "behind the scenes" storyboards, synced to the real narration with keyboard/UI sound effects. Use when the user shares a voice recording and/or a brief and wants an animated explainer video, a "how I made this" reel, a behind-the-scenes motion graphic, or asks to trim silences, sync scenes to speech, or mix voice + music + SFX. Always starts by asking the 3 standard questions (theme, audio mode, aspect ratio).
---

# Arabic Motion Reel Builder

Renders a deterministic HTML/CSS/JS animation frame by frame (Playwright + Chromium), mixes voice + SFX + soft music with ffmpeg, and outputs an MP4. Approved baseline = "v6": gold/dark cinematic theme, 9:16 (1080x1920), 6 scenes.

## Step 0 - Ask exactly these 3 questions (use AskUserQuestion, in Arabic), then build
1. **Theme** (max 3): A) Cinematic Gold (dark #0a0d14, gold #f0bd4a, lens/aperture motifs - the shipped template) · B) Neon Teal AI (deep navy, turquoise #47e3c3, command-bar/UI frames) · C) Clean Editorial (warm off-white, charcoal text, gold accent).
2. **Audio mode**: music only (no voice) / voice file only (no music) / voice + music in 2-3 sections between voice segments. All modes include SFX.
3. **Aspect ratio**: 9:16 (1080x1920) or 16:9 (1920x1080).
Do not ask anything else unless a blocker appears.

## Honest scope of the template
- `template/` implements **theme A in 9:16**. Theme B/C: change the colors in `:root` and the gradients/backgrounds in `index.html`/`app.js` (search `#f0bd4a`, `#47e3c3`, `#0a0d14`). 16:9: re-layout `index.html`/`app.js` to 1920x1080, set `size=[1920,1080]` in `timing.py` (cap.py reads it), and preview with snap.py before rendering. Verify visually; do not assume it works unchanged.
- Scene text, prompts, card titles are placeholders from the original brief - rewrite them for the new brief.

## Environment
`python3`, `ffmpeg`, `numpy`, `pillow`, `pip install playwright` + a Chromium (cap.py finds `/opt/pw-browsers/chromium-*` or the Playwright cache). Do not download browsers if one exists. Speech tool: `bash scripts/setup_asr.sh` (sherpa-onnx + Whisper small from GitHub releases; HuggingFace may be blocked).

## Workflow
1. `cp -r template /path/work && cd /path/work`. Put user images in `assets/` (names `ref1_lens.jpg`, `ref2_bus.jpg`, or edit the references). Never use frames from a user's video unless asked - extract audio only.
2. **Trim silence** (keeps a small natural breath): `python3 scripts/trim_silence.py voice.mp3 voice_trim.wav` -> also writes `voice_trim.map.json` ([old_start, old_end, new_start] pieces; new = new_start + t - old_start).
3. **Transcribe** the ORIGINAL voice: `python3 scripts/transcribe.py voice.mp3 ar` (phrase text + times; Whisper limit 30s per phrase). Convert times with the map. Dialect accuracy is approximate: confirm brand/product names with the user (e.g. which AI tool is named) before putting them on screen. A bigger model (Whisper medium, ~1.9GB) is better for the final pass.
4. **Retime**: in `timing.py` set `OLD` (authoring durations), `S` (scene boundaries on the trimmed voice, aligned to transcript phrases) and `K` offsets; scenes stretch by `F[i]`. Put each visual beat where the narrator says it (images when named, typing when "write the prompt", etc.). Set `SIG` (signature) and `total`. Run `python3 timing.py`.
5. **Preview** key moments: `python3 snap.py snaps/p 1 5 12 20 30 38` and look at them. Keep text inside the safe zone (x 70-1010, y 250-1480 for 9:16).
6. **Render frames** in parallel: `for k in 0 1 2 3; do python3 cap.py $k 4 & done; wait`. To redo a range only: `python3 cap.py K 4 START_FRAME`.
7. **Mix + encode**: `bash render.sh voice_trim.wav out.mp4` (generates SFX/music from `audio.py`, mixes, encodes). Voice must stay the loudest element; SFX x0.5 lowpass 9k ducked by voice; music x0.2 lowpass 1.2k ducked hard.
8. Send the MP4 for preview, iterate on user notes (time + what to change), commit sources.

## SFX / animation conventions (keep)
Shutter + whoosh on scene wipes (iris from the lens), mechanical keyboard on every typing animation, "bloop" per bouncing dot, pop per card/chip, chime on key reveals, downward whoosh + ping on music swap. Timeline scene: labeled VIDEO/VOICE/MUSIC/FX tracks, music wave gold->blue with the "تغيير الموسيقى" tag, play button below.

## Content rules
- Do not imply the AI tool made the whole animation; its role = description/planning unless the user says otherwise. Show interface mock-ups as "style samples", not real software.
- Use the correct official logo only where the brief asks (ChatGPT logo path is in `assets/openai_path.txt`; trademark belongs to its owner).
- Report honestly what was verified (frames viewed) vs not (audio was not listened to).
- Fonts: Tajawal + JetBrains Mono (SIL OFL) are bundled in `template/assets/`.
